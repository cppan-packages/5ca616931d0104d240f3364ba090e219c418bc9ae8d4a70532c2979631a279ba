extern int _testfunc_i_bhilfd(char b, short h, int i, long l, float f, double d);
